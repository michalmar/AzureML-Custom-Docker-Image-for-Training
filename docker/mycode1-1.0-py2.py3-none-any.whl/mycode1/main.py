def train():
    print("I am now running my secret code!")